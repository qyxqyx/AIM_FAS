Lists of train, dev, and test sets. There are 40, 15, 35 classes in each set, and images of each class are shown in a single text file. 
For each text file, each row presents an image. For example, for the '2_3_1.txt' file in the train set, its first row 'Train_images/2_3_01_1_012.jpg' presents the 12th frame of the '2_3_01_1' video in the original OULU train set.
